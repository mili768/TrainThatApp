package com.example.projekt.ui;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.projekt.R;
import com.example.projekt.adapters.Adapter;
import com.example.projekt.adapters.TrainingPreviewAdapter;
import com.example.projekt.models.ExerciseModel;
import com.example.projekt.models.TrainingModel;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.ArrayList;


public class TrainingPreview extends AppCompatActivity {

    private static final String TAG = "TrainingPreview";
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mManager;
    private TrainingPreviewAdapter mAdapter;
    private TrainingModel model;
    private ArrayList<ExerciseModel> exerciseModels;
    private ImageView deleteImage;
    private TextView title;
    private TextView time;
    private TextView days;
    private TextView type;
    private String reference;
    private String user;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference collectionReference = db.collection("user_training_created");

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trainingpreview);
        Intent intent = getIntent();
        if(intent.getExtras() != null){
            reference = intent.getExtras().getString("reference", null);
            user = intent.getExtras().getString("user", null);
        }

        
        model = Adapter.selectedTraining;
        exerciseModels = model.getExercises();

        mRecyclerView = findViewById(R.id.trainingRecyclerView);
        deleteImage = findViewById(R.id.training_delete);

        title = findViewById(R.id.training_name);
        time = findViewById(R.id.training_time);
        days = findViewById(R.id.training_days);
        type = findViewById(R.id.training_type);

        String timeString = "Czas trwania: " +  model.getTime() + "min";
        String daysString = "Ilość dni w tygodniu: " + model.getDays();
        String typeString = "Typ treningu: " + model.getType();

        if(model != null){
            title.setText(model.getName());
            time.setText(timeString);
            days.setText(daysString);
            type.setText(typeString);
        }

        initializeAdapter();

        if(user.equals("all")){
            deleteImage.setVisibility(View.GONE);
        }

        deleteImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(reference != null){
                    ConnectivityManager cm = (ConnectivityManager)TrainingPreview.this.getSystemService(Context.CONNECTIVITY_SERVICE);
                    NetworkInfo networkInfo = cm.getActiveNetworkInfo();
                    boolean connected = networkInfo != null && networkInfo.isConnectedOrConnecting();
                    if(connected){
                        final AlertDialog.Builder builder = new AlertDialog.Builder(TrainingPreview.this);
                        builder.setTitle(R.string.delete_alert_title);
                        builder.setMessage(R.string.delete_alert_subtitle);
                        builder.setPositiveButton("Usuń", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                ConnectivityManager cm = (ConnectivityManager)TrainingPreview.this.getSystemService(Context.CONNECTIVITY_SERVICE);
                                NetworkInfo networkInfo = cm.getActiveNetworkInfo();
                                boolean connected = networkInfo != null && networkInfo.isConnectedOrConnecting();
                                if(connected){
                                    deleteFromDb();
                                    dialog.dismiss();
                                    finish();
                                }
                                else{
                                    Toast.makeText(TrainingPreview.this, "Brak połączenia z siecią", Toast.LENGTH_LONG).show();
                                }
                            }
                        }).setNegativeButton("Anuluj", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                        builder.show();
                    }
                    else{
                        Toast.makeText(TrainingPreview.this, "Brak połączenia z siecią", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }

    private void initializeAdapter(){
        mAdapter = new TrainingPreviewAdapter(this, exerciseModels);
        mRecyclerView.setAdapter(mAdapter);
        mManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mManager);
        mRecyclerView.setHasFixedSize(true);
    }

    private void deleteFromDb(){

        collectionReference.document(reference)
                .delete()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(TrainingPreview.this, "Trening został usunięty", Toast.LENGTH_LONG).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(TrainingPreview.this, "Wystąpił błąd: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }
}
