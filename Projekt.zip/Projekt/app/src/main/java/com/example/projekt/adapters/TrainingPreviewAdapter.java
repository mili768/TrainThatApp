package com.example.projekt.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.projekt.R;
import com.example.projekt.models.ExerciseModel;
import java.util.ArrayList;

public class TrainingPreviewAdapter extends RecyclerView.Adapter<TrainingPreviewAdapter.RecyclerViewHolder> {

    private ArrayList<ExerciseModel> exList;
    Context ctx;

    public TrainingPreviewAdapter(Context ctx, ArrayList<ExerciseModel> exList){
        this.ctx = ctx;
        this.exList = exList;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(ctx).inflate(R.layout.activity_exercisepreview, parent, false);
        TrainingPreviewAdapter.RecyclerViewHolder recviewholder = new TrainingPreviewAdapter.RecyclerViewHolder(view);
        return recviewholder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, int position) {
        final ExerciseModel temp = exList.get(position);

        if(temp.getType().equals("siłowe")){
            holder.image.setImageResource(R.drawable.ic_silowe2);
        }else{
            holder.image.setImageResource(R.drawable.ic_cardio);
        }

        holder.title.setText(temp.getName());
        holder.type.setText(temp.getType());
        holder.muscle.setText(temp.getMuscle());
        holder.diff.setText(temp.getDifficulty());
        holder.desc.setText(temp.getDescription());
        String wholeCount = "Serie i powtórzenia / Czas: " + temp.getSeries() + " x " + temp.getCount();
        holder.seriesxcount.setText(wholeCount);
        holder.seriesxcount.setVisibility(View.VISIBLE);
    }

    @Override
    public int getItemCount() {
        return exList.size();
    }

    public static class RecyclerViewHolder extends RecyclerView.ViewHolder{

        public ImageView image;
        public TextView title;
        public TextView type;
        public TextView muscle;
        public TextView diff;
        public TextView desc;
        public TextView seriesxcount;

        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);

            image = itemView.findViewById(R.id.cardimage_ex);
            title = itemView.findViewById(R.id.cardtitle_ex);
            type = itemView.findViewById(R.id.cardtype_ex);
            muscle = itemView.findViewById(R.id.cardmuscle_ex);
            diff = itemView.findViewById(R.id.carddiff_ex);
            desc = itemView.findViewById(R.id.carddesc_ex);
            seriesxcount = itemView.findViewById(R.id.cardcount_ex);
        }
    }

}
