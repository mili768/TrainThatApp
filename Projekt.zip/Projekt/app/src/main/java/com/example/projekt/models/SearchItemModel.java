package com.example.projekt.models;

import java.util.ArrayList;

public class SearchItemModel {

    private ArrayList<ExerciseModel> exercises;

    public SearchItemModel(){

    }

    public SearchItemModel(ArrayList<ExerciseModel> exercises){
        this.exercises = exercises;
    }

    public ArrayList<ExerciseModel> getExercises() {
        return exercises;
    }

    public void setExercises(ArrayList<ExerciseModel> exercises) {
        this.exercises = exercises;
    }
}
