package com.example.projekt.ui;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.example.projekt.R;
import com.example.projekt.models.GamingTrainingModel;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import java.util.ArrayList;

public class HomeGaming extends AppCompatActivity {

    private static final String TAG = "HomeGaming";
    private FirebaseAuth mAuth;
    private Button btn1;
    private Button btn2;
    private Button btn3;
    private Button btn4;
    private Button btn5;
    private Button btn6;
    private Button btn7;
    public static ArrayList<GamingTrainingModel> allTrainings;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference collectionReference = db.collection("e_training_created");
    private static final String ACTION_MOVEMENT = "movement";
    private static final String ACTION_AIM = "aim";
    private static final String ACTION_RECOIL = "recoil";

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_g);

        mAuth = FirebaseAuth.getInstance();

        btn1 = findViewById(R.id.gaming_home_example_btn);
        btn2 = findViewById(R.id.gaming_home_your_btn);
        btn3 = findViewById(R.id.gaming_home_mvm_btn);
        btn4 = findViewById(R.id.gaming_home_maps_btn);
        btn5 = findViewById(R.id.gaming_home_aim_btn);
        btn6 = findViewById(R.id.gaming_home_rec_btn);
        btn7 = findViewById(R.id.gaming_home_logout_btn);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeGaming.this, ExampleGamingTraining.class);
                startActivity(intent);
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeGaming.this, ChooseItem.class);
                startActivity(intent);
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeGaming.this, GamingTrainingPreview.class);
                intent.setAction(ACTION_MOVEMENT);
                startActivity(intent);
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeGaming.this, GamingMaps.class);
                startActivity(intent);
            }
        });

        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeGaming.this, GamingTrainingPreview.class);
                intent.setAction(ACTION_AIM);
                startActivity(intent);
            }
        });

        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeGaming.this, GamingTrainingPreview.class);
                intent.setAction(ACTION_RECOIL);
                startActivity(intent);
            }
        });

        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sharedPreferences = getSharedPreferences("TrainThatApp", Context.MODE_PRIVATE);
                sharedPreferences.edit().clear();
                mAuth.signOut();
                finish();
            }
        });

        allTrainings = getAllTrainings(mAuth.getUid());
        getExampleTraining();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(mAuth != null){
            allTrainings = getAllTrainings(mAuth.getUid());
            getExampleTraining();
        }
    }

    public ArrayList<GamingTrainingModel> getAllTrainings(String id){

        final ArrayList<GamingTrainingModel> temp = new ArrayList<>();

        collectionReference
                .whereEqualTo("user", id)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                if(document.exists()){
                                    GamingTrainingModel model = document.toObject(GamingTrainingModel.class);
                                    model.setReference(document.getId());
                                    temp.add(model);
                                }
                            }
                        } else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.e(TAG, e.getMessage());
                    }
                });

        return temp;
    }

    public void getExampleTraining(){

        collectionReference.document("best_training_ever")
                .get()
                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if(task.isSuccessful()){
                            DocumentSnapshot document = task.getResult();
                            if(document.exists()){
                                allTrainings.add(document.toObject(GamingTrainingModel.class));
                                Log.d(TAG,allTrainings.get(0).getName());
                            }
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.e(TAG, e.getMessage());
            }
        });
    }

}
