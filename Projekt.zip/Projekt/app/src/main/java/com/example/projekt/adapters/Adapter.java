package com.example.projekt.adapters;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;
import com.example.projekt.models.Model;
import com.example.projekt.R;
import com.example.projekt.models.TrainingModel;
import com.example.projekt.ui.NewTraining;
import com.example.projekt.ui.TrainingPreview;

import java.util.List;

public class Adapter extends PagerAdapter {

    private List<Model> models;
    private LayoutInflater layoutinfl;
    private Context ctx;
    public static TrainingModel selectedTraining;

    public Adapter(List<Model> models, Context ctx) {
        this.models = models;
        this.ctx = ctx;
    }

    @Override
    public int getCount() {
        return models.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view.equals(object);
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, final int position) {

        layoutinfl = LayoutInflater.from(ctx);
        View v = layoutinfl.inflate(R.layout.item, container, false);
        ImageView img;
        TextView tit, desc;

        img = v.findViewById(R.id.image);
        tit = v.findViewById(R.id.titleCard);
        desc = v.findViewById(R.id.descCard);

        img.setImageResource(models.get(position).getImage());
        tit.setText(models.get(position).getTitle());
        desc.setText(models.get(position).getDescription());

        container.addView(v, 0);

        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(models.size() - 1 == position){
                    Intent intent = new Intent(ctx , NewTraining.class);

                    ctx.startActivity(intent);
                }
                else{
                    selectedTraining = models.get(position).getModel();
                    Intent intent = new Intent(ctx , TrainingPreview.class);
                    intent.putExtra("reference", models.get(position).getReference());
                    intent.putExtra("user", models.get(position).getModel().getUser());
                    ctx.startActivity(intent);
                }
            }
        });

        return v;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View)object);
    }

}
