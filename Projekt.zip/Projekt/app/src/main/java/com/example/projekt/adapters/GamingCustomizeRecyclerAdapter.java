package com.example.projekt.adapters;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.example.projekt.R;
import com.example.projekt.models.GamingExerciseModel;
import java.util.ArrayList;
import java.util.List;

public class GamingCustomizeRecyclerAdapter extends RecyclerView.Adapter<GamingCustomizeRecyclerAdapter.RecyclerViewHolder> {

    private Context ctx;
    public static ArrayList<GamingExerciseModel> exList;


    public GamingCustomizeRecyclerAdapter(Context ctx, ArrayList<GamingExerciseModel> exList){
        this.ctx = ctx;
        this.exList = exList;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(ctx).inflate(R.layout.item_gaming_exercise_preview, parent, false);
        GamingCustomizeRecyclerAdapter.RecyclerViewHolder recviewholder = new GamingCustomizeRecyclerAdapter.RecyclerViewHolder(view);
        return recviewholder;
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerViewHolder holder, int position) {

        final GamingExerciseModel temp = exList.get(position);
        List<String> types = new ArrayList<>();
        String map = "Map: " + temp.getMap();


        if(temp.isAim()){
            types.add("aim");
        }
        if(temp.isCp()){
            types.add("crosshair-placement");
        }

        if(temp.isMovement()){
            types.add("movement");
        }
        if(temp.isRecoil()){
            types.add("recoil");
        }

        String typesString = "Typ: " + types.toString();

        holder.card.setBackgroundColor(temp.isSelected() ? Color.LTGRAY: Color.WHITE);
        holder.name.setText(temp.getName());
        holder.map.setText(map);
        holder.desc.setText(temp.getDescription());
        holder.type.setText(typesString);

        holder.itemview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                temp.setSelected(!temp.isSelected());
                holder.card.setBackgroundColor(temp.isSelected() ? Color.LTGRAY: Color.WHITE);
            }
        });

        Log.d("ADAPTER", types.toString());
    }

    @Override
    public int getItemCount() {
        return exList.size();
    }

    public static class RecyclerViewHolder extends RecyclerView.ViewHolder{

        public CardView card;
        public View itemview;
        public TextView name;
        public TextView desc;
        public TextView type;
        public TextView map;
        public Button playbtn;

        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);

            card = itemView.findViewById(R.id.gaming_cardview);
            itemview = itemView;
            name = itemView.findViewById(R.id.gaming_titleCard);
            desc = itemView.findViewById(R.id.gaming_descCard);
            type = itemView.findViewById(R.id.gaming_type);
            map = itemView.findViewById(R.id.gaming_map);
            playbtn = itemView.findViewById(R.id.yt_link_btn);

            type.setVisibility(View.VISIBLE);
            playbtn.setVisibility(View.GONE);
        }
    }
}
