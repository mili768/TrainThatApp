package com.example.projekt.ui;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.projekt.R;
import com.example.projekt.adapters.CustomizeRecyclerAdapter;
import com.example.projekt.adapters.GamingCustomizeRecyclerAdapter;
import com.example.projekt.models.GamingExerciseModel;
import com.example.projekt.models.GamingTrainingModel;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import java.util.ArrayList;

public class CustomizeNewGamingPlan extends AppCompatActivity {

    private final static String TAG = "CustomizeNewGamingPlan";
    private RecyclerView recyclerView;
    private ArrayList<GamingExerciseModel> exercises;
    private LinearLayoutManager mManager;
    private GamingCustomizeRecyclerAdapter mAdapter;
    private Intent intent;
    private FirebaseAuth mAuth = FirebaseAuth.getInstance();
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference collectionReference = db.collection("e_training_created");
    public static ArrayList<GamingExerciseModel> selectedItems;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customize);
        intent = getIntent();

        ImageButton suwaki = findViewById(R.id.suwaki_customize);
        suwaki.setVisibility(View.GONE);

        TextView info = findViewById(R.id.customize_filter_info_tv);
        info.setVisibility(View.GONE);
        recyclerView = findViewById(R.id.customizeRecyclerView);

        Button zatwierdz = findViewById(R.id.customize_button);

        getGamingExercises();

        zatwierdz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedItems = new ArrayList<>();
                for(int i = 0; i< GamingCustomizeRecyclerAdapter.exList.size(); i++){
                    if(GamingCustomizeRecyclerAdapter.exList.get(i).isSelected()){
                        selectedItems.add(GamingCustomizeRecyclerAdapter.exList.get(i));
                    }
                }

                if(selectedItems.size() != 0){

                    String name = intent.getExtras().getString("name");
                    String desc = intent.getExtras().getString("description");
                    String user = mAuth.getUid();

                    addGamingTraining(selectedItems, name, desc, user);
                }
                else{
                    Toast.makeText(CustomizeNewGamingPlan.this, "Nie wybrano ćwiczeń", Toast.LENGTH_LONG).show();
                }
            }
        });
    }


    private void getGamingExercises(){
        exercises = new ArrayList<>();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Log.d("Gaming Exercises", "are being read...");

        db.collection("e_items")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                if(document.exists()){
                                    GamingExerciseModel model;
                                    model = document.toObject(GamingExerciseModel.class);
                                    exercises.add(model);
                                }
                            }
                            if(exercises.size() == task.getResult().size() && recyclerView != null){
                                initializeAdapter();
                            }
                        } else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                        }
                    }
                });
    }

    private void initializeAdapter() {
        mAdapter = new GamingCustomizeRecyclerAdapter(this, exercises);
        recyclerView.setAdapter(mAdapter);
        mManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(mManager);
        recyclerView.setHasFixedSize(true);
    }

    private void addGamingTraining(ArrayList<GamingExerciseModel> exercises, String name, String description, String user){

        GamingTrainingModel trainingToSend = new GamingTrainingModel(name, description, exercises);
        trainingToSend.setUser(user);

        collectionReference.add(trainingToSend)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Toast.makeText(CustomizeNewGamingPlan.this, "Udało się!", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(CustomizeNewGamingPlan.this, HomeGaming.class);
                        startActivity(intent);
                        finish();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.e(TAG, e.getMessage());
                        Toast.makeText(CustomizeNewGamingPlan.this, "Nie udało się dodać treningu", Toast.LENGTH_LONG).show();
                    }
                });
    }
}
