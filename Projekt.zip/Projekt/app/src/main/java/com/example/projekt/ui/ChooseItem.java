package com.example.projekt.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.example.projekt.R;
import com.example.projekt.models.GamingTrainingModel;
import java.util.ArrayList;
import java.util.List;

public class ChooseItem extends AppCompatActivity {

    private static final String TAG = "ChooseItem" ;
    private ListView listView;
    private List<String> names;
    private Button addBtn;
    public static ArrayList<GamingTrainingModel> copied;
    public static GamingTrainingModel selectedTraining;
    private static final String ACTION_NEW_GAMING_TRAINING = "gaming_add";


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose);

        names = new ArrayList<>();
        listView = findViewById(R.id.choose_listView);
        addBtn = findViewById(R.id.add_gaming_training_btn);

        copied = HomeGaming.allTrainings;

        for(int i = 0; i < copied.size(); i++){
            if(!copied.get(i).getUser().equals("all")){
                names.add(copied.get(i).getName());
            }
        }

        if(names != null){
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.search_item, R.id.searchitemtitle, names);
            listView.setAdapter(adapter);
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent intent = new Intent(ChooseItem.this, ExampleGamingTraining.class);
                    intent.setAction(ACTION_NEW_GAMING_TRAINING);
                    selectedTraining = copied.get(position);
                    startActivity(intent);
                }
            });
        }

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ChooseItem.this, NewTraining.class);
                intent.setAction(ACTION_NEW_GAMING_TRAINING);
                startActivity(intent);
            }
        });
    }

}
