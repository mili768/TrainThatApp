package com.example.projekt.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.projekt.R;
import com.example.projekt.adapters.CustomizeRecyclerAdapter;
import com.example.projekt.models.ExerciseModel;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import java.util.ArrayList;

public class CustomizeNewPlan extends AppCompatActivity {

    private static String TAG = "CustomizeNewPlan";
    private String name;
    private String desc;
    private int type;
    private ArrayList<ExerciseModel> modelList;
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mManager;
    private CustomizeRecyclerAdapter mAdapter;
    public static ArrayList<ExerciseModel> selectedItems;
    private SharedPreferences sharedPreferences;
    private String groupFilter;
    private Long age;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customize);
        mRecyclerView = findViewById(R.id.customizeRecyclerView);
        Intent intent = getIntent();
        type = intent.getExtras().getInt("type");
        name = intent.getExtras().getString("name");
        desc = intent.getExtras().getString("description");
        selectedItems = new ArrayList<>();
        Button zatwierdz = findViewById(R.id.customize_button);
        ImageButton filterBtn = findViewById(R.id.suwaki_customize);
        final TextView filterTv = findViewById(R.id.customize_filter_info_tv);
        filterTv.setText(R.string.customize_filter_main_text);

        sharedPreferences = getSharedPreferences("TrainThatApp", MODE_PRIVATE);
        age  = sharedPreferences.getLong("age", 0);

        if(age != 0){
            initializeGroup(age);
        }
        else{
            groupFilter = "";
        }

        getExByType(type);

        initializeAdapter();

        zatwierdz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedItems = new ArrayList<>();
                for(int i = 0; i<CustomizeRecyclerAdapter.exList.size(); i++){
                    if(CustomizeRecyclerAdapter.exList.get(i).isSelected()){
                        selectedItems.add(CustomizeRecyclerAdapter.exList.get(i));
                    }
                }
                if(selectedItems.size() != 0){
                    Intent intent = new Intent(CustomizeNewPlan.this, SetExerciseDetails.class);
                    if(name != null){
                        intent.putExtra("name", name);
                    }

                    if(desc != null){
                        intent.putExtra("description", desc);
                    }

                    intent.putExtra("type", type);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(CustomizeNewPlan.this, "Nie wybrano ćwiczeń", Toast.LENGTH_LONG).show();
                }
            }
        });

        filterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String text1 = getString(R.string.customize_filter_nofilter_text);
                String text2 = getString(R.string.customize_filter_main_text);

                if(filterTv.getText().toString().equals(text2)){
                    filterTv.setText(text1);
                    groupFilter = "";
                    getExByType(type);
                }
                else{
                    filterTv.setText(text2);
                    initializeGroup(age);
                    getExByType(type);
                }
            }
        });
    }

    private void getExByType(int type) {
        if(type == 0){
            getAllExercises(groupFilter);
        }
        else if(type == 1){
            getExercises("siłowe", groupFilter);
        }
        else{
            getExercises("cardio", groupFilter);
        }
    }

    private void getExercises(String type, String group){

        if(!group.equals("")){
            modelList = new ArrayList<>();
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            Log.d("Exercises", "are being read...");

            db.collection("items")
                    .whereEqualTo("type", type)
                    .whereEqualTo("group", group)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    if(document.exists()){
                                        ExerciseModel model;
                                        model = new ExerciseModel(document.get("name").toString(),document.get("description").toString(), document.get("group").toString(), document.get("type").toString(), document.get("muscle").toString(), document.get("difficulty").toString());
                                        modelList.add(model);
                                    }
                                }
                                if(modelList.size() == task.getResult().size() && mRecyclerView != null){
                                    initializeAdapter();
                                }
                            } else {
                                Log.d(TAG, "Error getting documents: ", task.getException());
                            }
                        }
                    });
        }
        else {
            modelList = new ArrayList<>();
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            Log.d("Exercises", "are being read...");

            db.collection("items")
                    .whereEqualTo("type", type)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    if(document.exists()){
                                        ExerciseModel model;
                                        model = new ExerciseModel(document.get("name").toString(),document.get("description").toString(), document.get("group").toString(), document.get("type").toString(), document.get("muscle").toString(), document.get("difficulty").toString());
                                        modelList.add(model);
                                    }
                                }
                                if(modelList.size() == task.getResult().size() && mRecyclerView != null){
                                    initializeAdapter();
                                }
                            } else {
                                Log.d(TAG, "Error getting documents: ", task.getException());
                            }
                        }
                    });
        }
    }


    private void getAllExercises(String group){
        if(!group.equals("")){
            modelList = new ArrayList<>();
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            Log.d("Exercises", "are being read...");

            db.collection("items")
                    .whereEqualTo("group", group)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    if(document.exists()){
                                        ExerciseModel model;
                                        model = new ExerciseModel(document.get("name").toString(),document.get("description").toString(), document.get("group").toString(), document.get("type").toString(), document.get("muscle").toString(), document.get("difficulty").toString());
                                        modelList.add(model);
                                    }
                                }
                                if(modelList.size() == task.getResult().size() && mRecyclerView != null){
                                    initializeAdapter();
                                }
                            } else {
                                Log.d(TAG, "Error getting documents: ", task.getException());
                            }
                        }
                    });
        }
        else{
            modelList = new ArrayList<>();
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            Log.d("Exercises", "are being read...");

            db.collection("items")
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    if(document.exists()){
                                        ExerciseModel model;
                                        model = new ExerciseModel(document.get("name").toString(),document.get("description").toString(), document.get("group").toString(), document.get("type").toString(), document.get("muscle").toString(), document.get("difficulty").toString());
                                        modelList.add(model);
                                    }
                                }
                                if(modelList.size() == task.getResult().size() && mRecyclerView != null){
                                    initializeAdapter();
                                }
                            } else {
                                Log.d(TAG, "Error getting documents: ", task.getException());
                            }
                        }
                    });
        }
    }


    private void initializeAdapter(){
        mAdapter = new CustomizeRecyclerAdapter(this, modelList);
        mRecyclerView.setAdapter(mAdapter);
        mManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mManager);
        mRecyclerView.setHasFixedSize(true);
    }

    private void initializeGroup(Long age){
        if(age != 0){
            if(age > 50){
                groupFilter = "każda";
            }
            else{
                groupFilter = "";
            }
        }
    }
}
