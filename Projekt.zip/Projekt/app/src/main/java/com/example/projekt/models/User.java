package com.example.projekt.models;

import java.util.List;

public class User {
    private String name;
    private int gender;
    private int age;
    private int active;
    List<String> plans;

    public User(){
        //PUSTY KONSTRUKTOR
    }

    public User(String name, int gender, int age, int active, List<String> plans){
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.active = active;
    }

    public String getName() {
        return name;
    }

    public int getGender() {
        return gender;
    }

    public int getAge() {
        return age;
    }

    public int getActive() {
        return active;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setActive(int active) {
        this.active = active;
    }
    public List<String> getPlans() {
        return plans;
    }

    public void setPlans(List<String> plans) {
        this.plans = plans;
    }

}
