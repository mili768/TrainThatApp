package com.example.projekt.dialogs;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;
import com.example.projekt.R;

public class SearchFilterDialog extends AppCompatDialogFragment {

    private Spinner spinner1;
    private Spinner spinner2;
    private String[] typeOptions = {" - ","siłowe", "cardio"};
    private String[] diffOptions = {" - ","początkujący", "średni", "trudny"};
    private String selectedType;
    private String selectedDiff;
    private SearchFilterDialogListener mListener;


    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.search_filter_dialog, null);

        builder.setView(view)
                .setTitle(R.string.search_dialog_title)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mListener.sendFilterData(selectedType, selectedDiff);
                    }
                }).setNegativeButton("Anuluj", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        spinner1 = view.findViewById(R.id.search_filter_spinner1);
        spinner2 = view.findViewById(R.id.search_filter_spinner2);

        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(getActivity(), R.layout.support_simple_spinner_dropdown_item, typeOptions);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getActivity(), R.layout.support_simple_spinner_dropdown_item, diffOptions);

        spinner1.setAdapter(adapter1);
        spinner2.setAdapter(adapter2);

        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch ((int) position){
                    case 0:
                        selectedType = null;
                        break;
                    case 1:
                        selectedType = "siłowe";
                        break;
                    case 2:
                        selectedType = "cardio";
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                selectedType = null;
            }
        });


        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch ((int) position){
                    case 0:
                        selectedDiff = null;
                        break;
                    case 1:
                        selectedDiff = "początkujący";
                        break;
                    case 2:
                        selectedDiff = "średni";
                        break;
                    case 3:
                        selectedDiff = "trudny";
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                selectedDiff = null;
            }
        });

        return builder.create();
    }

    public interface SearchFilterDialogListener{
        void sendFilterData(String type, String diff);
    }

    public void setOnItemSelectedListener(SearchFilterDialogListener listener){
        mListener = listener;
    }
}
