package com.example.projekt.models;

import java.util.ArrayList;

public class MapArrayModel {

    private ArrayList<MapModel> all;

    public MapArrayModel(){

    }

    public MapArrayModel(ArrayList<MapModel> all){
        this.all = all;
    }

    public ArrayList<MapModel> getAll() {
        return all;
    }

    public void setAll(ArrayList<MapModel> all) {
        this.all = all;
    }
}
