package com.example.projekt.models;

import java.util.ArrayList;

public class GamingTrainingModel {
    private String name;
    private String description;
    private ArrayList<GamingExerciseModel> exercises;
    private String user;
    private String reference;

    public GamingTrainingModel(){}

    public GamingTrainingModel(String name, String description, ArrayList<GamingExerciseModel> exercises){
        this.description = description;
        this.name = name;
        this.exercises = exercises;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ArrayList<GamingExerciseModel> getExercises() {
        return exercises;
    }

    public void setExercises(ArrayList<GamingExerciseModel> exercises) {
        this.exercises = exercises;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }
}
