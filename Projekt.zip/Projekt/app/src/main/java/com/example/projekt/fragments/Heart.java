package com.example.projekt.fragments;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import com.example.projekt.R;

public class Heart extends Fragment implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor sensor;
    private TextView title;
    private TextView subtitle;
    private int rate;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.element_heart, container, false);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT_WATCH)
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        title = getActivity().findViewById(R.id.heart_title);
        subtitle = getActivity().findViewById(R.id.heart_subtitle);
        rate = 0;

        requestPermissions(new String[]{Manifest.permission.BODY_SENSORS}, 1);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        Log.d("accuracy", String.valueOf(event.accuracy));
        Log.d("values", String.valueOf(event.values[0]));
        title.setText(String.valueOf((int)event.values[0]));
        if(event.values[0] > 60){
            rate = (int)event.values[0];
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

        if(accuracy == SensorManager.SENSOR_STATUS_NO_CONTACT || accuracy == SensorManager.SENSOR_STATUS_UNRELIABLE){
            Toast.makeText(getActivity(), "Pomiar zakończony!", Toast.LENGTH_LONG).show();
            if(rate != 0){
                String subtitleString = "Ostatni pomiar: " + rate;
                subtitle.setText(subtitleString);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
            initializeSensor();
        }
        else{
            Toast.makeText(getActivity(), "Błąd dostępu!", Toast.LENGTH_SHORT).show();
        }
    }

    private void initializeSensor(){
        sensorManager = (SensorManager) getActivity().getSystemService(Context.SENSOR_SERVICE);
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_HEART_RATE);
        if(sensor != null){
            sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
        else{
            title.setText("Nie wykryto odpowiedniego sensora");
        }
    }
}
