package com.example.projekt.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;
import com.example.projekt.adapters.Adapter;
import com.example.projekt.adapters.ArticleItemAdapter;
import com.example.projekt.models.ArticleModel;
import com.example.projekt.models.Model;
import com.example.projekt.R;
import com.example.projekt.models.TrainingModel;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import java.util.ArrayList;
import java.util.List;


public class Home extends Fragment {

    private static final String TAG = "Home";
    ViewPager pager;
    Adapter adapter;
    List<Model> list;
    private ListView listView;
    private ArrayList<ArticleModel> articlesList;
    private FirebaseAuth mAuth = FirebaseAuth.getInstance();
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference collectionReference = db.collection("user_training_created");

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.element_home, container, false);
    }

    //ZRODLA: https://smartgym.club/blog/ile-razy-w-tygodniu-trenowac-silowo/

    //WFORMIE24.PL

    //FITNESS WP PL

    //OPTYMALNA ILOSC TRENINGU 4x w tyg - siłowy

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        list = new ArrayList<>();
        listView = getActivity().findViewById(R.id.article_listView);
        articlesList = new ArrayList<>();


        list.add(new Model(R.drawable.button, "Nowy plan", "Dodaj nowy plan treningowy.", new TrainingModel()));

        initializeAdapter();

        getArticles();
        getUserTrainings(mAuth.getUid());
        getDefaultTraining();

        pager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onResume() {
        super.onResume();
        list = new ArrayList<>();
        list.add(new Model(R.drawable.button, "Nowy plan", "Dodaj nowy plan treningowy.", new TrainingModel()));
        getUserTrainings(mAuth.getUid());
        getDefaultTraining();
        initializeAdapter();
    }

    private void initializeAdapter() {

        if(getActivity()!=null) {
            adapter = new Adapter(list, getContext());
            pager = getActivity().findViewById(R.id.viewPager);
            pager.setAdapter(adapter);
        }
    }

    private void getUserTrainings(String id) {
        collectionReference
                .whereEqualTo("user", id)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                if(document.exists()){
                                    int image;
                                    if(document.get("type").toString().equals("siłowe")){
                                        image = R.drawable.ic_silowe2;
                                    }
                                    else if (document.get("type").toString().equals("cardio")){
                                        image = R.drawable.ic_cardio;
                                    }
                                    else{
                                        image = R.drawable.ic_mix;
                                    }

                                    TrainingModel trainingModel = document.toObject(TrainingModel.class);
                                    trainingModel.setImage(image);
                                    boolean ok = true;


                                    Model model = new Model(image, trainingModel.getName(), trainingModel.getDescription(), trainingModel);
                                    model.setReference(document.getId());

                                    for(int i = 0; i<list.size(); i++){
                                        if(list.get(i).getTitle().equals(model.getTitle())){
                                            ok = false;
                                        }
                                    }

                                    if(ok){
                                        list.add(0, model);
                                    }

                                    initializeAdapter();
                                }
                            }
                        } else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });
    }

    private void getDefaultTraining() {
        collectionReference
                .whereEqualTo("user", "all")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                if(document.exists()){
                                    int image;
                                    if(document.get("type").toString().equals("siłowe")){
                                        image = R.drawable.ic_silowe2;
                                    }
                                    else if (document.get("type").toString().equals("cardio")){
                                        image = R.drawable.ic_cardio;
                                    }
                                    else{
                                        image = R.drawable.ic_mix;
                                    }

                                    TrainingModel trainingModel = document.toObject(TrainingModel.class);
                                    trainingModel.setImage(image);
                                    boolean ok = true;


                                    Model model = new Model(image, trainingModel.getName(), trainingModel.getDescription(), trainingModel);
                                    model.setReference(document.getId());

                                    for(int i = 0; i<list.size(); i++){
                                        if(list.get(i).getTitle().equals(model.getTitle())){
                                            ok = false;
                                        }
                                    }

                                    if(ok){
                                        list.add(0, model);
                                    }

                                    initializeAdapter();
                                }
                            }
                        } else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });
    }

    private void getArticles(){

        Log.d("Articles", "are being read...");

        db.collection("articles")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                if(document.exists()){
                                    ArticleModel article;
                                    article = new ArticleModel(document.get("title").toString(),document.get("body").toString());
                                    articlesList.add(article);
                                }
                            }
                            if(articlesList.size() == task.getResult().size() && listView != null && getActivity() != null){
                                ArticleItemAdapter articleAdapter = new ArticleItemAdapter(getActivity(), articlesList);
                                listView.setAdapter(articleAdapter);
                            }
                        } else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                        }
                    }
                });

    }
}
