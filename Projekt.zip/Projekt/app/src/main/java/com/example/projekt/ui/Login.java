package com.example.projekt.ui;

import android.accounts.NetworkErrorException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.example.projekt.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import java.io.File;
import java.io.IOException;


public class Login extends AppCompatActivity {

    private static final String TAG = "Login";
    TextView textview;
    private FirebaseAuth mAuth;
    private StorageReference mStorageRef;
    private SharedPreferences shared;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        textview = findViewById(R.id.registerTx);
        mAuth = FirebaseAuth.getInstance();
        mStorageRef = FirebaseStorage.getInstance().getReference();
        FirebaseUser user = mAuth.getCurrentUser();
        shared = getSharedPreferences("TrainThatApp", MODE_PRIVATE);

        if(user != null)
        {
            ConnectivityManager cm = (ConnectivityManager)Login.this.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();
            boolean connected = networkInfo != null && networkInfo.isConnectedOrConnecting();
            if(connected){
                getUserDetails();
                Intent intent = new Intent(Login.this, SecondClass.class);
                startActivity(intent);
                finish();
            }
            else{
                Toast.makeText(Login.this, "Brak połączenia z siecią", Toast.LENGTH_LONG).show();
                finish();
            }
        }

        final EditText emailView = findViewById(R.id.emailLogin);
        final EditText passView = findViewById(R.id.hasloLogin);
        Button login = findViewById(R.id.loginBtn);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!authorize())
                {
                    return;
                }

                String email = emailView.getText().toString();
                String password = passView.getText().toString();
                mAuth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(Login.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful())
                                {
                                    Log.d("SUKCES", "signInWithEmail:success");
                                    getUserDetails();
                                    try {
                                        getUserPhoto();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                    Intent intent = new Intent(Login.this, SecondClass.class);
                                    startActivity(intent);
                                    finish();
                                }
                                else
                                    {
                                    Toast.makeText(Login.this, task.getException().getMessage(),
                                            Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });
    }

    private boolean authorize()
    {
        boolean ok = true;
        EditText emailView = findViewById(R.id.emailLogin);
        EditText passView = findViewById(R.id.hasloLogin);
        String email = emailView.getText().toString();
        String password = passView.getText().toString();

        if(TextUtils.isEmpty(email))
        {
            ok = false;
            emailView.setError("Pole nie może być puste.");
        }
        else{
            emailView.setError(null);
        }
        if(TextUtils.isEmpty(password))
        {
            ok = false;
            passView.setError("Pole nie może być puste.");
        }
        else{
            passView.setError(null);
        }
        return ok;
    }


    public void onClick(View v){
        Intent intent = new Intent(this, Register.class);
        startActivity(intent);
   }

   public void getUserDetails(){

        FirebaseFirestore db = FirebaseFirestore.getInstance();
       final DocumentReference doc = db.collection("users").document(mAuth.getUid());
       Log.d("USER", "GETTING DETAILS...");

       doc.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
           @Override
           public void onComplete(@NonNull Task<DocumentSnapshot> task) {
               if (task.isSuccessful()) {

                   DocumentSnapshot document = task.getResult();

                   if (document.exists()) {
                       Log.d("OK", "DocumentSnapshot data: " + document.getData());
                       try{

                           SharedPreferences sharedPreferences = getSharedPreferences("TrainThatApp", MODE_PRIVATE);
                           SharedPreferences.Editor edit = sharedPreferences.edit();
                           edit.putString("name", document.get("name").toString()).apply();
                           edit.putLong("age", (long)document.get("age")).apply();
                           edit.putString("gender", document.get("gender").toString()).apply();

                           Long active = (Long) document.get("active");

                           if (active == 0) {
                           } else if (active == 1) {
                               edit.putString("active", "Brak aktywności fizycznej").apply();
                           } else if (active == 2) {
                               edit.putString("active", "Mała aktywność fizyczna").apply();
                           } else if (active == 3) {
                               edit.putString("active", "średnia aktywność fizyczna").apply();
                           } else if (active == 4) {
                               edit.putString("active", "Duża aktywność fizyczna").apply();
                           }

                           edit.apply();
                       }
                       catch (Exception e){
                           Log.e("Exception", e.getMessage());
                       }
                   } else {
                       Log.d("NO", "No such document");
                   }
               } else {
                   Log.d("EXC", "get failed with ", task.getException());
               }
           }
       });
   }

   private void getUserPhoto() throws IOException {
        try{
            StorageReference imageRef = mStorageRef.child("images/" + mAuth.getCurrentUser().getUid());
            final File localFile = File.createTempFile("images", "jpg");
            imageRef.getFile(localFile)
                    .addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                            if(shared != null){
                                shared.edit().putString("image_path", localFile.getAbsolutePath()).apply();
                            }
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception exception) {

                }
            });
        }
        catch(Exception e){
            Log.e("ERROR", e.getMessage());
       }

   }
}
