package com.example.projekt.adapters;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.example.projekt.R;
import com.example.projekt.models.ArticleModel;
import java.util.ArrayList;

public class ArticleItemAdapter extends ArrayAdapter<ArticleModel> {

    public ArticleItemAdapter(@NonNull Context context, ArrayList<ArticleModel> list) {

        super(context, 0, list);
        Log.d("CCOTEXT",context.toString());
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        ArticleModel temp = (ArticleModel)getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.article_item, parent, false);
        }

        TextView title = convertView.findViewById(R.id.article_title);
        TextView body = convertView.findViewById(R.id.descArticle);

        assert temp != null;
        title.setText(temp.getTitle());
        body.setText(temp.getBody());

        return convertView;
    }
}
