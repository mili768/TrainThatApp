package com.example.projekt.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.projekt.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class Register extends AppCompatActivity {

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        mAuth = FirebaseAuth.getInstance();
        mAuth.setLanguageCode("pl");

        final EditText emailView = findViewById(R.id.emailTx);
        final EditText pass = findViewById(R.id.passwordTx);
        Button register = findViewById(R.id.registerBtn);

        register.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if(!autoryzacja()) {
                    return;
                }

                String email = emailView.getText().toString();
                String password = pass.getText().toString();
                mAuth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(Register.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(Register.this, "Pomyślnie utworzono konto.", Toast.LENGTH_LONG).show();
                                    mAuth.signOut();
                                    Log.d("SUKCES", "createUserWithEmail:success");
                                    Intent intent = new Intent(Register.this, Login.class);
                                    startActivity(intent);
                                    finish();
                                } else {
                                    Log.w("BLAD", "createUserWithEmail:failure", task.getException());
                                    Toast.makeText(Register.this, "Błąd: wprowadzony email jest niepoprawny bądź jest już używany.", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                }
        });

    }

    private boolean autoryzacja(){
        boolean ok = true;
        final EditText emailView = findViewById(R.id.emailTx);
        final EditText pass = findViewById(R.id.passwordTx);
        final EditText passConf = findViewById(R.id.passwordConfTx);
        String email = emailView.getText().toString();
        String password = pass.getText().toString();
        String confPass = passConf.getText().toString();

        if(TextUtils.isEmpty(email)){
            ok = false;
            emailView.setError("Pole nie może być puste.");
        }
        else{
            emailView.setError(null);
        }

        if(TextUtils.isEmpty(password)){
            pass.setError("Pole nie może być puste.");
            ok = false;
        }
        else{
            pass.setError(null);
        }

        if(TextUtils.isEmpty(confPass)){
            passConf.setError("Pole nie może być puste.");
            ok = false;
        }
        else{
            passConf.setError(null);
        }

        if(TextUtils.equals(password, confPass)){
            if(pass.length() < 8){
                pass.setError("Hasło jest za krótkie.");
                passConf.setError("Hasło jest za krótkie.");
                ok = false;
            }
        }
        else{
            passConf.setError("Hasła nie są takie same.");
            ok = false;
        }

        return ok;
    }

    public void onRegisterClick(View v){
        Intent intent = new Intent(this, Login.class);
        startActivity(intent);
        finish();
    }
}
