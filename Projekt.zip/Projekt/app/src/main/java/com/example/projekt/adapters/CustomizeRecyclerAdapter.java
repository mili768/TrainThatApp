package com.example.projekt.adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.example.projekt.R;
import com.example.projekt.models.ExerciseModel;
import java.util.ArrayList;

public class CustomizeRecyclerAdapter extends RecyclerView.Adapter<CustomizeRecyclerAdapter.RecyclerViewHolder> {

    private Context ctx;
    public static ArrayList<ExerciseModel> exList;

    public CustomizeRecyclerAdapter(Context ctx, ArrayList<ExerciseModel> exList){
        this.ctx = ctx;
        this.exList = exList;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(ctx).inflate(R.layout.activity_exercisepreview, parent, false);
        CustomizeRecyclerAdapter.RecyclerViewHolder recviewholder = new CustomizeRecyclerAdapter.RecyclerViewHolder(view, exList);
        return recviewholder;
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerViewHolder holder, int position) {
        final ExerciseModel temp = exList.get(position);
        if(temp.getType().equals("siłowe")){
            holder.image.setImageResource(R.drawable.ic_silowe2);
        }else{
            holder.image.setImageResource(R.drawable.ic_cardio);
        }

        holder.card.setBackgroundColor(temp.isSelected() ? Color.LTGRAY : Color.WHITE);
        holder.title.setText(temp.getName());
        holder.type.setText(temp.getType());
        holder.muscle.setText(temp.getMuscle());
        holder.diff.setText(temp.getDifficulty());
        holder.desc.setText(temp.getDescription());

        holder.itemview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                temp.setSelected(!temp.isSelected());
                holder.card.setBackgroundColor(temp.isSelected() ? Color.LTGRAY: Color.WHITE);
            }
        });

    }

    @Override
    public int getItemCount() {
        return exList.size();
    }

    public static class RecyclerViewHolder extends RecyclerView.ViewHolder{

        public CardView card;
        public View itemview;
        public ImageView image;
        public TextView title;
        public TextView type;
        public TextView muscle;
        public TextView diff;
        public TextView desc;

        public RecyclerViewHolder(@NonNull View itemView, final ArrayList<ExerciseModel> models) {
            super(itemView);


            card = itemView.findViewById(R.id.search_card);
            itemview = itemView;
            image = itemView.findViewById(R.id.cardimage_ex);
            title = itemView.findViewById(R.id.cardtitle_ex);
            type = itemView.findViewById(R.id.cardtype_ex);
            muscle = itemView.findViewById(R.id.cardmuscle_ex);
            diff = itemView.findViewById(R.id.carddiff_ex);
            desc = itemView.findViewById(R.id.carddesc_ex);


        }
    }
}
