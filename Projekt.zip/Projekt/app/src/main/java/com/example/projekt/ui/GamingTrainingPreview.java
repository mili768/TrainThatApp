package com.example.projekt.ui;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.projekt.R;
import com.example.projekt.adapters.GamingTrainingRecyclerAdapter;
import com.example.projekt.models.GamingExerciseModel;
import com.example.projekt.services.YTClass;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import java.util.ArrayList;

public class GamingTrainingPreview extends Activity {

    private static final String TAG = "GamingTrainingPreview";
    private static final String ACTION_MOVEMENT = "movement";
    private static final String ACTION_AIM = "aim";
    private static final String ACTION_RECOIL = "recoil";
    private ArrayList<GamingExerciseModel> exercises;
    private GamingTrainingRecyclerAdapter adapter;
    private TextView name;
    private TextView desc;
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager mManager;
    private ImageView delete;
    private Button ytBtn;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference collectionReference = db.collection("e_items_template");

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gaming_best_training);

        recyclerView = findViewById(R.id.RecyclerView_gaming_best);
        name = findViewById(R.id.gaming_training_name);
        desc = findViewById(R.id.training_description);
        delete = findViewById(R.id.training_delete);
        ytBtn = findViewById(R.id.yt_link_btn);
        mManager = new LinearLayoutManager(this);

        Intent intent = getIntent();
        String action = intent.getAction();

        if(action != null){
            switch(intent.getAction()){
                case ACTION_MOVEMENT:
                    getMovement();
                    getExercises(ACTION_MOVEMENT);
                    break;
                case ACTION_AIM:
                    getAim();
                    getExercises(ACTION_AIM);
                    break;
                case ACTION_RECOIL:
                    getRecoil();
                    getExercises(ACTION_RECOIL);
                    break;
            }
        }
    }

    private void getMovement() {
        collectionReference.document(ACTION_MOVEMENT)
                .get()
                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if(task.isSuccessful()){
                            DocumentSnapshot document = task.getResult();
                            if(document.exists()){
                                String name = document.get("title").toString();
                                String desc = document.get("description").toString();
                                final String url = document.get("url").toString();

                                GamingTrainingPreview.this.name.setText(name);
                                GamingTrainingPreview.this.desc.setText(desc);
                                GamingTrainingPreview.this.ytBtn.setVisibility(View.VISIBLE);
                                GamingTrainingPreview.this.ytBtn.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        setYTClick(url);
                                    }
                                });
                            }
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.e(TAG, e.getMessage());
            }
        });
    }


    private void getAim() {
        collectionReference.document(ACTION_AIM)
                .get()
                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if(task.isSuccessful()){
                            DocumentSnapshot document = task.getResult();
                            if(document.exists()){
                                String name = document.get("title").toString();
                                String desc = document.get("description").toString();
                                final String url = document.get("url").toString();

                                GamingTrainingPreview.this.name.setText(name);
                                GamingTrainingPreview.this.desc.setText(desc);
                                GamingTrainingPreview.this.ytBtn.setVisibility(View.VISIBLE);
                                GamingTrainingPreview.this.ytBtn.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        setYTClick(url);
                                    }
                                });
                            }
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.e(TAG, e.getMessage());
            }
        });
    }


    private void getRecoil() {
        collectionReference.document(ACTION_RECOIL)
                .get()
                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if(task.isSuccessful()){
                            DocumentSnapshot document = task.getResult();
                            if(document.exists()){
                                String name = document.get("title").toString();
                                String desc = document.get("description").toString();
                                final String url = document.get("url").toString();

                                GamingTrainingPreview.this.name.setText(name);
                                GamingTrainingPreview.this.desc.setText(desc);
                                GamingTrainingPreview.this.ytBtn.setVisibility(View.VISIBLE);
                                GamingTrainingPreview.this.ytBtn.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        setYTClick(url);
                                    }
                                });
                            }
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.e(TAG, e.getMessage());
            }
        });
    }


    private void getExercises(String action){

        exercises = new ArrayList<>();

        db.collection("e_items")
                .whereEqualTo(action, true)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                if(document.exists()){
                                    GamingExerciseModel model;
                                    model = document.toObject(GamingExerciseModel.class);
                                    exercises.add(model);
                                }
                            }
                            if(exercises.size() == task.getResult().size() && recyclerView != null){
                                initializeAdapter();
                            }
                        } else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                        }
                    }
                });
    }


    private void initializeAdapter() {
        if(exercises != null){

            adapter = new GamingTrainingRecyclerAdapter(GamingTrainingPreview.this, exercises);

            if(recyclerView != null){
                recyclerView.setAdapter(adapter);
                recyclerView.setLayoutManager(mManager);
            }
        }
    }


    private void setYTClick(String url){

        ConnectivityManager cm = (ConnectivityManager)GamingTrainingPreview.this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
        boolean connected = networkInfo != null && networkInfo.isConnectedOrConnecting();
        if(connected){
            Intent intent = new Intent(GamingTrainingPreview.this, YTClass.class);
            intent.putExtra("url", url);
            GamingTrainingPreview.this.startActivity(intent);
        }
        else{
            Toast.makeText(GamingTrainingPreview.this, "Brak połączenia z siecią", Toast.LENGTH_LONG).show();
        }
    }


}
