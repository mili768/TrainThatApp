package com.example.projekt.models;

public class GamingExerciseModel {

    private String name;
    private String description;
    private String map;
    private String url;
    private boolean recoil;
    private boolean aim;
    private boolean cp;
    private boolean movement;
    private boolean isSelected = false;

    public GamingExerciseModel(){
    }

    public GamingExerciseModel(String name, String description, String map, String url){
        this.name = name;
        this.description = description;
        this.map = map;
        this.url = url;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getMap() {
        return map;
    }

    public void setMap(String map) {
        this.map = map;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public boolean isRecoil() {
        return recoil;
    }

    public void setRecoil(boolean recoil) {
        this.recoil = recoil;
    }

    public boolean isAim() {
        return aim;
    }

    public void setAim(boolean aim) {
        this.aim = aim;
    }

    public boolean isCp() {
        return cp;
    }

    public void setCp(boolean cp) {
        this.cp = cp;
    }

    public boolean isMovement() {
        return movement;
    }

    public void setMovement(boolean movement) {
        this.movement = movement;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }


    public boolean isSelected() {
        return isSelected;
    }
}
