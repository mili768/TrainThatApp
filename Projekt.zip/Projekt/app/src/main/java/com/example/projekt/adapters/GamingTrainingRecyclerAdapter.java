package com.example.projekt.adapters;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.projekt.R;
import com.example.projekt.models.GamingExerciseModel;
import com.example.projekt.services.YTClass;
import java.util.ArrayList;

public class GamingTrainingRecyclerAdapter extends RecyclerView.Adapter<GamingTrainingRecyclerAdapter.RecyclerViewHolder> {

    private Context ctx;
    private ArrayList<GamingExerciseModel> models;

    public GamingTrainingRecyclerAdapter(Context ctx, ArrayList<GamingExerciseModel> models){
        this.ctx = ctx;
        this.models = models;
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(ctx).inflate(R.layout.item_gaming_exercise_preview, parent, false);
        GamingTrainingRecyclerAdapter.RecyclerViewHolder recyclerViewHolder = new GamingTrainingRecyclerAdapter.RecyclerViewHolder(view, ctx, models);
        return recyclerViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolder holder, final int position) {
        final GamingExerciseModel temp = models.get(position);

        holder.name.setText(temp.getName());
        holder.desc.setText(temp.getDescription());
        holder.map.setText(temp.getMap());
    }

    @Override
    public int getItemCount() {
        return models.size();
    }

    public static class RecyclerViewHolder extends RecyclerView.ViewHolder{

        public TextView name;
        public TextView desc;
        public TextView map;
        public Button btn;

        public RecyclerViewHolder(@NonNull View itemView, final Context ctx, final ArrayList<GamingExerciseModel> models) {
            super(itemView);

            name = itemView.findViewById(R.id.gaming_titleCard);
            desc = itemView.findViewById(R.id.gaming_descCard);
            map = itemView.findViewById(R.id.gaming_map);
            btn = itemView.findViewById(R.id.yt_link_btn);
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ConnectivityManager cm = (ConnectivityManager)ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
                    NetworkInfo networkInfo = cm.getActiveNetworkInfo();
                    boolean connected = networkInfo != null && networkInfo.isConnectedOrConnecting();
                    if(connected){
                        Intent intent = new Intent(ctx, YTClass.class);
                        intent.putExtra("url", models.get(getAdapterPosition()).getUrl());
                        ctx.startActivity(intent);
                    }
                    else{
                        Toast.makeText(ctx, "Brak połączenia z siecią", Toast.LENGTH_LONG).show();
                    }
                }
            });

        }
    }


}
