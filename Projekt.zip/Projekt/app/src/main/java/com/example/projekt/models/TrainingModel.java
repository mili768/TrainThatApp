package com.example.projekt.models;

import java.util.ArrayList;

public class TrainingModel {

    private String name;
    private String description;
    private long days;
    private long time;
    private ArrayList<ExerciseModel> exercises;
    private String user;
    private String type;
    private int image;

    public TrainingModel(){}

    public TrainingModel(String name, String type, long days, long time, ArrayList<ExerciseModel> exercises, String user){
        this.name = name;
        this.days = days;
        this.time = time;
        this.exercises = exercises;
        this.user = user;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public long getDays() {
        return days;
    }

    public void setDays(int days) {
        this.days = days;
    }

    public long getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public ArrayList<ExerciseModel> getExercises() {
        return exercises;
    }

    public void setExercises(ArrayList<ExerciseModel> exercises) {
        this.exercises = exercises;
    }

    public String getUser() {
        return user;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
