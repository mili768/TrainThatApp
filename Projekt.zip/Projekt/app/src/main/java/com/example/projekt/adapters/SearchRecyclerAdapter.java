package com.example.projekt.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.projekt.R;
import com.example.projekt.models.ExerciseModel;
import java.util.ArrayList;

public class SearchRecyclerAdapter extends RecyclerView.Adapter<SearchRecyclerAdapter.RecyclerviewHolder> {

    private Context ctx;
    private ArrayList<ExerciseModel> exList;
    private ArrayList<ExerciseModel> exListFiltered;
    public OnItemClickListener mListener;

    public SearchRecyclerAdapter(Context ctx, ArrayList<ExerciseModel> exList){
        this.ctx = ctx;
        this.exList = exList;
        this.exListFiltered = exList;
    }

    public interface OnItemClickListener{
        void OnItemClick(ExerciseModel item);
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        mListener = listener;
    }

    @NonNull
    @Override
    public RecyclerviewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(ctx).inflate(R.layout.search_item, parent, false);
        RecyclerviewHolder recviewholder = new RecyclerviewHolder(view, mListener);
        return recviewholder;
    }

    @Override
    public void onBindViewHolder(@NonNull SearchRecyclerAdapter.RecyclerviewHolder holder, int position) {

        ExerciseModel temp = exListFiltered.get(position);
        holder.image.setImageResource(R.drawable.ic_baseline_arrow_forward_ios_24);
        holder.title.setText(temp.getName());
    }

    @Override
    public int getItemCount() {
        return exListFiltered.size();
    }

    public class RecyclerviewHolder extends RecyclerView.ViewHolder{

        public ImageView image;
        public TextView title;

        public RecyclerviewHolder(@NonNull final View itemView, final OnItemClickListener listener) {
            super(itemView);

            title = itemView.findViewById(R.id.searchitemtitle);
            image = itemView.findViewById(R.id.searchitem_image);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.OnItemClick(exListFiltered.get(getAdapterPosition()));
                }
            });

        }
    }

    public Filter newfilter(){
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                if(constraint.toString().isEmpty()){
                    exListFiltered = exList;
                }
                else{
                    ArrayList<ExerciseModel> tmp = new ArrayList<>();
                    for(ExerciseModel item: exList){
                        if(item.getName().toLowerCase().contains(constraint.toString().toLowerCase())){
                            tmp.add(item);
                        }
                    }
                    exListFiltered = tmp;
                }

                FilterResults results = new FilterResults();
                results.values = exListFiltered;
                return results;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                exListFiltered = (ArrayList<ExerciseModel>)results.values;
                notifyDataSetChanged();
            }
        };
    }
}
