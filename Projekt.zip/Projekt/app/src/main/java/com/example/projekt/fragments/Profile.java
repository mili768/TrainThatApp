package com.example.projekt.fragments;

import android.Manifest;
import android.app.Instrumentation;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.example.projekt.ui.EditProfile;
import com.example.projekt.R;
import com.example.projekt.services.RotateImage;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

import static android.app.Activity.RESULT_OK;


public class Profile extends Fragment {

    private FirebaseAuth mAuth;
    private FirebaseUser user;
    private FirebaseStorage storage;
    private StorageReference storageReference;
    private TextView name;
    private TextView age;
    private TextView plec;
    private TextView akt;
    private ImageView image;
    private ProgressBar progressBar;
    private SharedPreferences sharedPreferences;
    private Uri imageUri;
    private Bitmap mBitmap;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        sharedPreferences = getActivity().getSharedPreferences("TrainThatApp", Context.MODE_PRIVATE);
        mAuth = FirebaseAuth.getInstance();
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();
        user = mAuth.getCurrentUser();
        return inflater.inflate(R.layout.element_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        TextView email = getView().findViewById(R.id.profile_email_tv);
        Button edit = getView().findViewById(R.id.editProfile);
        Button logout = getView().findViewById(R.id.logOutBtn);
        image = getView().findViewById(R.id.profilePic);
        progressBar = getView().findViewById(R.id.progressBarPic);

        name = getActivity().findViewById(R.id.profile_name_tv);
        age = getActivity().findViewById(R.id.profile_wiek_tv);
        plec = getActivity().findViewById(R.id.profile_plec_tv);
        akt = getActivity().findViewById(R.id.profile_aktywnosc_tv);


        if(sharedPreferences.getString("image_path", null ) == null){
            image.setVisibility(View.VISIBLE);
        }
        else{
            image.setVisibility(View.INVISIBLE);
            getUserPhoto();
        }

        getUserData();

        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getActivity(), EditProfile.class));
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sharedPreferences = getActivity().getSharedPreferences("TrainThatApp", Context.MODE_PRIVATE);
                sharedPreferences.edit().clear();
                mAuth.signOut();
                getActivity().finish();
            }
        });

        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);

            }
        });

        email.setText(user.getEmail());

        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onResume() {
        super.onResume();
        getUserData();
        //getUserPhoto();
    }

    private void getUserData() {

        if(sharedPreferences.getString("name", null) != null &&
                sharedPreferences.getString("gender", null) != null && sharedPreferences.getLong("age", 0) != 0) {

            name.setText("Witaj " + sharedPreferences.getString("name", null) + "!");
            age.setText(String.valueOf(sharedPreferences.getLong("age", 0)));
            plec.setText(sharedPreferences.getString("gender", null));
            akt.setText(sharedPreferences.getString("active", null));
        }
    }

    private void choosePicture(){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, 1);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == 1 && resultCode == RESULT_OK && data != null){
            imageUri = data.getData();
            try {
                mBitmap = MediaStore.Images.Media.getBitmap(this.getContext().getContentResolver(), imageUri);
                imageUri = rotate(imageUri);
                uploadPicture();
                image.setImageURI(imageUri);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private Uri rotate(Uri imageUri) {
        RotateImage rotate = new RotateImage();
        String path = "";
        if(mBitmap != null){
            try {
                mBitmap = rotate.HandleSamplingAndRotationBitmap(getActivity(), imageUri);
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                mBitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
                path = MediaStore.Images.Media.insertImage(getContext().getContentResolver(), mBitmap, "Title", null);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return Uri.parse(path);
    }

    private void uploadPicture(){

        final ProgressDialog dialog = new ProgressDialog(getContext());
        dialog.setTitle("Przesyłanie obrazu...");
        dialog.show();

        final String docName= user.getUid();
        final StorageReference riversRef = storageReference.child("images/" + docName);

        riversRef.putFile(imageUri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        dialog.dismiss();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        dialog.dismiss();
                        Toast.makeText(getContext(), "Failed" + exception.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                    double percentage = (100.00 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                    dialog.setMessage((int)percentage + "%");
            }
        });
    }


    private void getUserPhoto(){

        try{
            progressBar.setVisibility(View.VISIBLE);
            StorageReference imageRef = storageReference.child("images/" + user.getUid());
            final File localFile = File.createTempFile("images", "jpg");
            imageRef.getFile(localFile)
                    .addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                            if(sharedPreferences != null){
                                sharedPreferences.edit().putString("image_path", localFile.getAbsolutePath()).apply();
                                File imgFile = new  File(localFile.getAbsolutePath());
                                Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
                                image.setImageBitmap(myBitmap);
                                image.setVisibility(View.VISIBLE);
                                progressBar.setVisibility(View.INVISIBLE);
                            }
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception exception) {
                    progressBar.setVisibility(View.INVISIBLE);
                }
            }).addOnProgressListener(new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
                @Override
                public void onProgress(@NonNull FileDownloadTask.TaskSnapshot snapshot) {
                    progressBar.setProgress((int) (100.00 * snapshot.getBytesTransferred() / snapshot.getTotalByteCount()));
                }
            });
        }
        catch(Exception e){
            Log.e("ERROR", e.getMessage());
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
            choosePicture();
        }else{
            Toast.makeText(getActivity(), "Błąd dostępu!", Toast.LENGTH_SHORT).show();
        }
    }

}
