package com.example.projekt.ui;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.example.projekt.R;
import com.example.projekt.services.YTClass;

public class NewTraining extends AppCompatActivity {

    private int choice;
    private Button continueBtn;
    private EditText nameEt;
    private EditText descEt;
    private Intent intent;
    private Spinner spinner;
    private TextView label;
    private static final String ACTION_NEW_GAMING_TRAINING = "gaming_add";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_plan);
        spinner = findViewById(R.id.rodzajTreninguSpin);
        label = findViewById(R.id.spinner_label);

        intent = getIntent();

        if(intent.getAction() != null){
            if(intent.getAction().equals(ACTION_NEW_GAMING_TRAINING )){
                addGamingTraining();
            }
        }

        else{
            String[] type = {"różne", "siłowe", "cardio"};
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item, type);

            spinner.setAdapter(adapter);
            spinner.setSelection(0);
            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int id, long position) {
                    switch ((int) position){
                        case 0:
                            choice = 0;
                            break;
                        case 1:
                            choice = 1;
                            break;
                        case 2:
                            choice = 2;
                            break;
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {
                    choice = 0;
                }
            });
        }


        continueBtn = findViewById(R.id.newplan_continueBtn);
        nameEt = findViewById(R.id.newTitle);
        descEt = findViewById(R.id.newDesc);

        continueBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!authorise()){
                    return;
                }

                if(intent.getAction() != null){
                    if(intent.getAction().equals(ACTION_NEW_GAMING_TRAINING)){

                        ConnectivityManager cm = (ConnectivityManager)NewTraining.this.getSystemService(Context.CONNECTIVITY_SERVICE);
                        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
                        boolean connected = networkInfo != null && networkInfo.isConnectedOrConnecting();

                        if(connected){
                            Intent intent = new Intent(NewTraining.this, CustomizeNewGamingPlan.class);
                            intent.putExtra("name", nameEt.getText().toString());

                            if(!descEt.getText().toString().equals("")){
                                intent.putExtra("description", descEt.getText().toString());
                            }
                            startActivity(intent);
                        }
                        else{
                            Toast.makeText(NewTraining.this, "Brak połączenia z siecią", Toast.LENGTH_LONG).show();
                        }

                    }
                }
                else{
                    ConnectivityManager cm = (ConnectivityManager)NewTraining.this.getSystemService(Context.CONNECTIVITY_SERVICE);
                    NetworkInfo networkInfo = cm.getActiveNetworkInfo();
                    boolean connected = networkInfo != null && networkInfo.isConnectedOrConnecting();
                    if(connected){
                        Intent intent = new Intent(NewTraining.this, CustomizeNewPlan.class);
                        intent.putExtra("name", nameEt.getText().toString());

                        if(!descEt.getText().toString().equals("")){
                            intent.putExtra("description", descEt.getText().toString());
                        }
                        intent.putExtra("type", choice);
                        startActivity(intent);
                    }
                    else{
                        Toast.makeText(NewTraining.this, "Brak połączenia z siecią", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
    }

    private void addGamingTraining() {
        spinner.setVisibility(View.GONE);
        label.setVisibility(View.GONE);
    }

    private boolean authorise(){
        boolean ok = true;
        nameEt = findViewById(R.id.newTitle);
        String name = nameEt.getText().toString();

        if(TextUtils.isEmpty(name))
        {
            ok = false;
            nameEt.setError("Pole nie może być puste.");
        }
        else{
            nameEt.setError(null);
        }
        return ok;
    }
}
