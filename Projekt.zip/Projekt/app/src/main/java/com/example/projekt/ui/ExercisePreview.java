package com.example.projekt.ui;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.example.projekt.R;
import com.example.projekt.fragments.Search;
import com.example.projekt.models.ExerciseModel;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;



public class ExercisePreview extends AppCompatActivity {

    private static final String TAG = "ExercisePreview";
    private CardView mCardView;
    private TextView cardTitle;
    private TextView cardDesc;
    private TextView cardExType;
    private TextView cardMuscle;
    private TextView cardDiff;
    private ImageView image;
    private ExerciseModel item;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercisepreview);

        item = Search.selectedExercise;

        getCurrentExercise();

        mCardView = findViewById(R.id.search_card);
        cardDesc = findViewById(R.id.carddesc_ex);
        cardTitle = findViewById(R.id.cardtitle_ex);
        cardDiff = findViewById(R.id.carddiff_ex);
        cardExType = findViewById(R.id.cardtype_ex);
        cardMuscle = findViewById(R.id.cardmuscle_ex);
        image = findViewById(R.id.cardimage_ex);

        if(mCardView!=null && item != null){
            if(item.getType().equals("siłowe")){
                image.setImageResource(R.drawable.ic_silowe2);
            }
            else if(item.getType().equals("cardio")){
                image.setImageResource(R.drawable.ic_cardio);
            }
        }
    }

    private void getCurrentExercise() {

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Log.d("Exercises", "are being read...");

        db.collection("items").whereEqualTo("name", item.getName())
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                if(document.exists()){
                                    item = document.toObject(ExerciseModel.class);
                                    updateUi();
                                }
                                else{
                                    Log.e(TAG, "Document does not exist");
                                }
                            }
                        } else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                        }
                    }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });
    }

    private void updateUi() {
        cardTitle.setText(item.getName());
        cardDesc.setText(item.getDescription());
        String type = cardExType.getText() + " " + item.getType();
        cardExType.setText(type);
        String diff = cardDiff.getText() + " " + item.getDifficulty();
        cardDiff.setText(diff);
        String muscle = cardMuscle.getText() + " " + item.getMuscle();
        cardMuscle.setText(muscle);
        mCardView.setVisibility(View.VISIBLE);
    }
}
