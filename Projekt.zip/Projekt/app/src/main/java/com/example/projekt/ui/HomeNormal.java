package com.example.projekt.ui;
import android.os.Bundle;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.example.projekt.R;
import com.example.projekt.fragments.Footsteps;
import com.example.projekt.fragments.Heart;
import com.example.projekt.fragments.Home;
import com.example.projekt.fragments.Profile;
import com.example.projekt.fragments.Search;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class HomeNormal extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_n);
        BottomNavigationView btmNav = findViewById(R.id.navigation_bar);
        btmNav.setOnNavigationItemSelectedListener(listener);
        getSupportFragmentManager().beginTransaction().replace(R.id.element_container, new Home()).commit();
    }

    private BottomNavigationView.OnNavigationItemSelectedListener listener = new BottomNavigationView.OnNavigationItemSelectedListener(){

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment selected = null;

            switch(item.getItemId()){
                case R.id.menu_1:
                    selected = new Home();
                    break;
                case R.id.menu_2:
                    selected = Search.newInstance();
                    break;
                case R.id.menu_3:
                    selected = new Heart();
                    break;
                case R.id.menu_4:
                    selected = new Footsteps();
                    break;
                case R.id.menu_5:
                    selected = new Profile();
                    break;
            }
            getSupportFragmentManager().beginTransaction().replace(R.id.element_container, selected).commit();
            return true;
        }
    };

}
