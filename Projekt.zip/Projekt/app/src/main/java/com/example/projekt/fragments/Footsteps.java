package com.example.projekt.fragments;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import com.example.projekt.R;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Footsteps extends Fragment implements SensorEventListener {

    private static final String TAG = "Footsteps";
    public TextView footstepsTv;
    private SensorManager sensorManager;
    private Sensor sensor;
    private SharedPreferences pref;
    private String today;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.element_footsteps, container, false);
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        footstepsTv = getActivity().findViewById(R.id.footsteps_count_tv);
        TextView dateTv = getActivity().findViewById(R.id.footsteps_date_tv);
        pref = getActivity().getSharedPreferences("TrainThatApp", Context.MODE_PRIVATE);

        Date date = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
        today = dateFormat.format(date);
        dateTv.setText(today);

        requestPermissions(new String[]{Manifest.permission.ACTIVITY_RECOGNITION}, 1);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onResume() {
        super.onResume();
        initializeSensor();
    }


    @Override
    public void onSensorChanged(SensorEvent event) {
        Log.d("SENSRO", sensorManager.toString());

        if(pref.getString("Date", null) != null){
            if(!pref.getString("Date", null).equals(today)){
                pref.edit().putInt("Count", (int) event.values[0]).apply();
                pref.edit().putString("Date", today).apply();
                footstepsTv.setText(String.valueOf(0));
            }
            else{
                int prev = pref.getInt("Count", 0);
                int current = (int) event.values[0] - prev;
                if(current > 0){
                    pref.edit().putInt("Current", current).apply();
                    footstepsTv.setText(String.valueOf(current));
                }
            }
        }
        else{
            pref.edit().putInt("Count", (int) event.values[0]).apply();
            pref.edit().putString("Date", today).apply();
            footstepsTv.setText(String.valueOf(0));
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
            initializeSensor();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void initializeSensor() {
        sensorManager = (SensorManager) getActivity().getSystemService(Context.SENSOR_SERVICE);
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);

        if(sensor != null){
            sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
        else{
            footstepsTv.setText("Urządzenie nie posiada odpowiedniego sensora");
        }
    }
}
