package com.example.projekt.adapters;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.projekt.R;
import com.example.projekt.models.ExerciseModel;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;

public class SettingSeriesAdapter extends RecyclerView.Adapter<SettingSeriesAdapter.RecyclerViewHolder> {

    private Context ctx;
    public static ArrayList<ExerciseModel> exList;
    private int seriesValues [];
    private int countValues [];

    public SettingSeriesAdapter(Context ctx, ArrayList<ExerciseModel> exList){
        this.ctx = ctx;
        this.exList = exList;
        this.seriesValues = new int[getItemCount()];
        this.countValues = new int[getItemCount()];
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(ctx).inflate(R.layout.ex_set_item, parent, false);
        SettingSeriesAdapter.RecyclerViewHolder recviewholder = new SettingSeriesAdapter.RecyclerViewHolder(view);
        return recviewholder;
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerViewHolder holder, int position) {

        ExerciseModel temp = exList.get(position);
        holder.name.setText(temp.getName());
        holder.series.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                seriesValues[holder.getAdapterPosition()] = Integer.parseInt(holder.series.getText().toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        holder.count.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                countValues[holder.getAdapterPosition()] = Integer.parseInt(holder.count.getText().toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @Override
    public int getItemCount() {
        return exList.size();
    }

    public static class RecyclerViewHolder extends RecyclerView.ViewHolder {

        public TextView name;
        public EditText series;
        public EditText count;

        public RecyclerViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.ex_set_name);
            series = itemView.findViewById(R.id.series);
            count = itemView.findViewById(R.id.count);
        }
    }

    public int[] getSeries(){
        return this.seriesValues;
    }

    public int[] getCount(){
        return this.countValues;
    }

}
