package com.example.projekt.services;

import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.example.projekt.R;

public class YTClass extends AppCompatActivity {

    private String url;
    private WebView view;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yt);
        Intent intent = getIntent();

        if(intent.getExtras() != null){
            url = intent.getExtras().getString("url", null);
        }

        view = findViewById(R.id.yt_webView);
        if(url != null){
            view.getSettings().setJavaScriptEnabled(true);
            view.setWebChromeClient(new WebChromeClient(){});
            view.loadUrl(url);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        finish();
    }
}
