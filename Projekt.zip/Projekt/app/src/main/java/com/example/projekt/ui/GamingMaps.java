package com.example.projekt.ui;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.example.projekt.R;
import com.example.projekt.models.MapArrayModel;
import com.example.projekt.models.MapModel;
import com.example.projekt.services.YTClass;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.ArrayList;
import java.util.List;

public class GamingMaps extends AppCompatActivity {

    private static final String TAG = "ChooseItem" ;
    private final String documentString = "maps";
    private ListView listView;
    private ArrayList<MapModel> mapList;
    private Button addBtn;
    private TextView title;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference collectionReference = db.collection("e_items_template");

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose);

        listView = findViewById(R.id.choose_listView);
        addBtn = findViewById(R.id.add_gaming_training_btn);
        title = findViewById(R.id.map_choose_title);
        addBtn.setVisibility(View.GONE);
        title.setVisibility(View.VISIBLE);

        getMapsSmallData();

    }

    private void getMapsSmallData(){
        mapList = new ArrayList<>();
        Log.d("Maps", "are being read...");

        collectionReference.document(documentString)
                .get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if(task.isSuccessful()){
                    DocumentSnapshot document = task.getResult();
                    if(document.exists()){
                        MapArrayModel newmodel = document.toObject(MapArrayModel.class);
                        if(newmodel != null){
                            mapList = newmodel.getAll();
                            initializeAdapter();
                        }
                    }
                    else{
                        Log.e(TAG, "Document does not exist");
                    }
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.e(TAG, e.getMessage());
            }
        });
    }

    private void initializeAdapter(){

        final List<String> names = new ArrayList<>();

        for(int i = 0; i < mapList.size(); i++){
            if(mapList.get(i) != null){
                names.add(mapList.get(i).getName());
            }
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.search_item, R.id.searchitemtitle, names);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                ConnectivityManager cm = (ConnectivityManager)GamingMaps.this.getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo networkInfo = cm.getActiveNetworkInfo();
                boolean connected = networkInfo != null && networkInfo.isConnectedOrConnecting();
                if(connected){
                    Intent intent = new Intent(GamingMaps.this, YTClass.class);
                    intent.putExtra("url", mapList.get(position).getUrl());
                    startActivity(intent);
                }
                else{
                    Toast.makeText(GamingMaps.this, "Brak połączenia z siecią", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
