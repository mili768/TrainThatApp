package com.example.projekt.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.projekt.R;
import com.example.projekt.adapters.SearchRecyclerAdapter;
import com.example.projekt.dialogs.SearchFilterDialog;
import com.example.projekt.models.ExerciseModel;
import com.example.projekt.models.SearchItemModel;
import com.example.projekt.ui.ExercisePreview;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.ArrayList;

public class Search extends Fragment {

    private static String TAG = "SearchFragment";
    private RecyclerView mRecyclerView;
    private SearchRecyclerAdapter mAdapter;
    private RecyclerView.LayoutManager mManager;
    private ArrayList<ExerciseModel> modelList;
    private EditText mSearchfield;
    private ImageView mChangeFilter;
    public static ExerciseModel selectedExercise;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){
        View v = inflater.inflate(R.layout.element_search, container, false);
        mRecyclerView = v.findViewById(R.id.recyclerView);
        mSearchfield = v.findViewById(R.id.searchfield);
        mChangeFilter = v.findViewById(R.id.suwaki);
        return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        getSampleExerciseData();
        initializeAdapter();

        mChangeFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filter();
            }
        });

        mSearchfield.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(mAdapter != null){
                    mAdapter.newfilter().filter(s);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        super.onViewCreated(view, savedInstanceState);
    }

    public static Search newInstance(){
        return new Search();
    }

    private void getSampleExerciseData() {
        modelList = new ArrayList<ExerciseModel>();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Log.d("Exercises", "are being read...");

        db.collection("items_template").document("items_small_data")
                .get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if(task.isSuccessful()){
                    DocumentSnapshot document = task.getResult();
                    if(document.exists()){
                        SearchItemModel newmodel = document.toObject(SearchItemModel.class);
                        if(newmodel != null){
                            modelList = newmodel.getExercises();
                            initializeAdapter();
                        }
                    }
                    else{
                        Log.e(TAG, "Document does not exist");
                    }
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });
    }

    private void filter(){

        SearchFilterDialog dialog = new SearchFilterDialog();
        dialog.show(getActivity().getSupportFragmentManager(), "search");
        dialog.setOnItemSelectedListener(new SearchFilterDialog.SearchFilterDialogListener()
        {
            @Override
            public void sendFilterData(String type, String diff) {

                ArrayList<ExerciseModel> filteredList = new ArrayList<>();

                try{
                    if(type != null && diff != null && modelList.size() != 0){
                        for(int i=0; i < modelList.size(); i++){
                            Log.d("LISt", String.valueOf(modelList.get(i)));
                            if(modelList.get(i).getType().equals(type) && modelList.get(i).getDifficulty().equals(diff)){
                                filteredList.add(modelList.get(i));
                            }
                        }
                    }
                    else if(type == null && diff != null && modelList.size() != 0){
                        for(int i=0; i < modelList.size(); i++){
                            if(modelList.get(i).getDifficulty().equals(diff)){
                                filteredList.add(modelList.get(i));
                            }
                        }
                    }
                    else if(type != null && diff == null && modelList.size() != 0){
                        for(int i=0; i < modelList.size(); i++){
                            if(modelList.get(i).getType().equals(type)){
                                filteredList.add(modelList.get(i));
                            }
                        }
                    }
                    else{
                        filteredList = modelList;
                    }

                    mAdapter = new SearchRecyclerAdapter(getContext(), filteredList);
                    mRecyclerView.setAdapter(mAdapter);
                    mManager = new LinearLayoutManager(getActivity());
                    mRecyclerView.setLayoutManager(mManager);
                    mRecyclerView.setHasFixedSize(true);
                    mAdapter.setOnItemClickListener(new SearchRecyclerAdapter.OnItemClickListener() {
                        @Override
                        public void OnItemClick(ExerciseModel item) {
                            if(item != null){
                                selectedExercise = item;
                                Log.d(TAG, item.getName());
                                startActivity(new Intent(getActivity(), ExercisePreview.class));
                            }
                        }
                    });
                }
                catch(Exception e){
                    Toast.makeText(getActivity(), "Sprawdź dostęp do sieci", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void initializeAdapter(){
        mAdapter = new SearchRecyclerAdapter(getContext(), modelList);
        mRecyclerView.setAdapter(mAdapter);
        mManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mManager);
        mRecyclerView.setHasFixedSize(true);
        mAdapter.setOnItemClickListener(new SearchRecyclerAdapter.OnItemClickListener() {
            @Override
            public void OnItemClick(ExerciseModel item) {
                if(item != null){
                    selectedExercise = item;
                    Log.d(TAG, item.getName());
                    startActivity(new Intent(getActivity(), ExercisePreview.class));
                }
            }
        });
    }

}
