package com.example.projekt.ui;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.projekt.R;
import com.example.projekt.adapters.GamingTrainingRecyclerAdapter;
import com.example.projekt.models.GamingExerciseModel;
import com.example.projekt.models.GamingTrainingModel;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.ArrayList;


public class ExampleGamingTraining extends AppCompatActivity {

    private static final String TAG = "ExampleGamingTraining";
    private String action;
    private GamingTrainingModel model;
    private TextView name;
    private TextView desc;
    private GamingTrainingRecyclerAdapter adapter;
    private ArrayList<GamingExerciseModel> exercises;
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager mManager;
    private ImageView delete;
    private String reference;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference collectionReference = db.collection("e_training_created");
    private static final String ACTION_NEW_GAMING_TRAINING = "gaming_add";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gaming_best_training);

        Intent intent = getIntent();
        action = intent.getAction();

        recyclerView = findViewById(R.id.RecyclerView_gaming_best);
        name = findViewById(R.id.gaming_training_name);
        desc = findViewById(R.id.training_description);
        delete = findViewById(R.id.training_delete);
        mManager = new LinearLayoutManager(this);

        if(action != null){
            if(action.equals(ACTION_NEW_GAMING_TRAINING)){
                if(ChooseItem.selectedTraining != null){
                    model = ChooseItem.selectedTraining;
                    reference = model.getReference();
                }

                delete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(reference != null){
                            ConnectivityManager cm = (ConnectivityManager)ExampleGamingTraining.this.getSystemService(Context.CONNECTIVITY_SERVICE);
                            NetworkInfo networkInfo = cm.getActiveNetworkInfo();
                            boolean connected = networkInfo != null && networkInfo.isConnectedOrConnecting();
                            if(connected){
                                final AlertDialog.Builder builder = new AlertDialog.Builder(ExampleGamingTraining.this);
                                builder.setTitle(R.string.delete_alert_title);
                                builder.setMessage(R.string.delete_alert_subtitle);
                                builder.setPositiveButton("Usuń", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        ConnectivityManager cm = (ConnectivityManager)ExampleGamingTraining.this.getSystemService(Context.CONNECTIVITY_SERVICE);
                                        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
                                        boolean connected = networkInfo != null && networkInfo.isConnectedOrConnecting();
                                        if(connected){
                                            deleteFromDb();
                                            dialog.dismiss();
                                            Intent intent = new Intent(ExampleGamingTraining.this, HomeGaming.class);
                                            startActivity(intent);
                                            finish();
                                        }
                                        else{
                                            Toast.makeText(ExampleGamingTraining.this, "Brak połączenia z siecią", Toast.LENGTH_LONG).show();
                                        }
                                    }
                                }).setNegativeButton("Anuluj", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });
                                builder.show();
                            }
                            else{
                                Toast.makeText(ExampleGamingTraining.this, "Brak połączenia z siecią", Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                });
                initializeAdapter();
            }
        }
        else{
            for(int i =0; i< HomeGaming.allTrainings.size(); i++){
                if(HomeGaming.allTrainings.get(i).getUser().equals("all")){
                    model = HomeGaming.allTrainings.get(i);
                }
            }
            delete.setVisibility(View.GONE);
            initializeAdapter();
        }

    }


    private void initializeAdapter() {
        if(model != null){

            exercises = model.getExercises();

            if(exercises != null){
                adapter = new GamingTrainingRecyclerAdapter(ExampleGamingTraining.this, exercises);
            }

            if(recyclerView != null){
                recyclerView.setAdapter(adapter);
                recyclerView.setLayoutManager(mManager);
            }

            name.setText(model.getName());
            desc.setText(model.getDescription());

        }
    }

    private void deleteFromDb(){

        collectionReference.document(reference)
                .delete()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(ExampleGamingTraining.this, "Trening został usunięty", Toast.LENGTH_LONG).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(ExampleGamingTraining.this, "Wystąpił błąd: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }

}
