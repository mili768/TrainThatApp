package com.example.projekt.ui;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.projekt.R;
import com.example.projekt.adapters.SettingSeriesAdapter;
import com.example.projekt.models.ExerciseModel;
import com.example.projekt.models.TrainingModel;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;


public class SetExerciseDetails extends AppCompatActivity {

    private static final String TAG = "SetExerciseDetails";
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mManager;
    private SettingSeriesAdapter mAdapter;
    private ArrayList<ExerciseModel> copiedArray;
    private String realName;
    private String realDescription;
    private String desc;
    private TextView nameTv;
    private TextView descTv;
    private EditText days;
    private int series[];
    private int count[];
    private int type;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference collectionReference = db.collection("user_training_created");
    private FirebaseAuth mAuth = FirebaseAuth.getInstance();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exdetails);

        Intent intent = getIntent();
        nameTv = findViewById(R.id.plan_title);
        descTv = findViewById(R.id.plan_desc);
        days = findViewById(R.id.plan_days);
        Button addPlan = findViewById(R.id.add_new_plan_btn);
        ImageView showInfo = findViewById(R.id.exdetails_more_info);

        realName = intent.getExtras().getString("name");
        type = intent.getExtras().getInt("type");

        String name = "Nazwa planu: " + realName;

        if(intent.getExtras().getString("description") != null && !intent.getExtras().getString("description").equals("")){
            desc = "Opis planu: " + intent.getExtras().getString("description");
            realDescription = intent.getExtras().getString("description");
        }
        else{
            desc = "Opis planu: ";
        }

        nameTv.setText(name);
        descTv.setText(desc);
        copiedArray = CustomizeNewPlan.selectedItems;
        mRecyclerView = findViewById(R.id.recyclerView_details);
        initializeAdapter();

        addPlan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                series = mAdapter.getSeries();
                count = mAdapter.getCount();

                if(!autorize()){
                    return;
                }
                if(!adapterAutorize()){
                    return;
                }

                ArrayList<ExerciseModel> exArray = SettingSeriesAdapter.exList;
                ArrayList<Map> exercises = new ArrayList<>();

                for(int i = 0; i<exArray.size(); i++){

                    Map<String, Object> exercise = new HashMap<>();
                    ExerciseModel model = exArray.get(i);
                    exercise.put("name", model.getName());
                    exercise.put("description", model.getDescription());
                    exercise.put("difficulty", model.getDifficulty());
                    exercise.put("count", count[i]);
                    exercise.put("muscle", model.getMuscle());
                    exercise.put("series", series[i]);
                    exercise.put("type", model.getType());

                    exercises.add(exercise);
                }
                for(int i = 0; i<exArray.size(); i++){
                    exArray.get(i).setSeries(series[i]);
                    exArray.get(i).setCount(count[i]);
                }

                int duration = getDuration(series, count)/60;
                String trainingType = "";

                switch(type){
                    case 0:
                        trainingType = "różne";
                        break;
                    case 1:
                        trainingType = "siłowe";
                        break;
                    case 2:
                        trainingType = "cardio";
                        break;
                    }

                TrainingModel newDbPlan = new TrainingModel(realName, trainingType, Integer.parseInt(days.getText().toString()), duration, exArray, mAuth.getUid());
                if(realDescription != null){
                    newDbPlan.setDescription(realDescription);
                }
                collectionReference.add(newDbPlan)
                        .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                            @Override
                            public void onSuccess(DocumentReference documentReference) {
                                Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.getId());
                                Toast.makeText(SetExerciseDetails.this, "Udało się!", Toast.LENGTH_LONG).show();
                                Intent intent = new Intent(SetExerciseDetails.this, HomeNormal.class);
                                startActivity(intent);
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(SetExerciseDetails.this, "Wystąpił błąd.", Toast.LENGTH_LONG).show();
                                Log.w(TAG, "Error adding document", e);
                            }
                        });
            }
        });

        showInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog alertDialog = new AlertDialog.Builder(SetExerciseDetails.this).create();
                alertDialog.setIcon(R.drawable.ic_baseline_info_24);
                alertDialog.setTitle("Trochę informacji");
                alertDialog.setMessage("W przypadku tworzenia planu siłowego ważne jest odpowiednie dobranie ilości ćwiczeń do wytrzymałości oraz obciążenia odpowiedniego dla twojego poziomu siły." +
                        "Optymalna ilość treningów tygodniowo to 3-4. Jeśli twoja aktywność jest duża to możesz ćwiczyć częściej. Podczas treningu czysto siłowego należy wykonywać mniejszą ilość powtórzeń" +
                        "przy zastosowaniu obciążenia oraz zwiększyć ilość serii. Pomiędzy seriami należy odpoczywać do pełnej regeneracji. W przypadku treningu cardio - średnia intensywność treningu " +
                        "oznacza utrzymanie tętna przez cały czas wysiłku na poziomie 60-70% maksymalnego tętna. Trening główny powinien trwać około 30 minut, a najlepiej 45 minut. Można też wykonywać " +
                        "od 3 do nawet 6 treningów dziennie (10 min – 15 min jedna sesja). Przed tobą twój generator treningu i to od Ciebie zależy jak go spersonalizujesz! :)");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
            }
        });
    }


    private boolean adapterAutorize() {

        boolean ok = true;
        if(series.length != SettingSeriesAdapter.exList.size() || count.length != SettingSeriesAdapter.exList.size()){
            Toast.makeText(SetExerciseDetails.this, "Uzupełnij wszystkie pola", Toast.LENGTH_LONG).show();
            ok = false;
        }

        for(int i = 0; i<series.length; i++){
            if(series[i] == 0 && count[i] == 0){
                Toast.makeText(SetExerciseDetails.this, "Pola nie mogą być zerami", Toast.LENGTH_LONG).show();
                ok = false;
            }
        }
        return ok;
    }

    private void initializeAdapter(){
        mAdapter = new SettingSeriesAdapter(this, copiedArray);
        mRecyclerView.setAdapter(mAdapter);
        mManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mManager);
        mRecyclerView.setHasFixedSize(true);
    }

    private boolean autorize() {
        boolean ok = true;

        String daysCount = days.getText().toString();

        if(TextUtils.isEmpty(daysCount))
        {
            ok = false;
            days.setError("Pole nie może być puste.");
        }
        else{
            days.setError(null);
        }
        return ok;
    }

    private int getDuration(int[] s, int[] c){

        int duration = 0;
        int totalSeries = 0;

        for(int i = 0; i< s.length; i++){
            totalSeries += s[i];
            duration += 10 * s[i] * c[i];
        }

        duration += 10 * totalSeries;
        return duration;
    }

}

