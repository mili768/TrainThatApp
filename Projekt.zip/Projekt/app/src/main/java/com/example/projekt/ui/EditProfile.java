package com.example.projekt.ui;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.example.projekt.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class EditProfile extends AppCompatActivity {

    private String pl = "";
    private int akt = 0;
    private FirebaseAuth mAuth;
    private FirebaseUser user;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editprofile);

        mAuth = FirebaseAuth.getInstance();
        user = mAuth.getCurrentUser();
        String[] aktywnosc = {"brak", "mała", "średnia", "duża"};

        final Spinner spinner = findViewById(R.id.aktywnoscSpin);
        final EditText imieView = findViewById(R.id.imieEt);
        final EditText wiekView = findViewById(R.id.wiekEt);
        final Button save = findViewById(R.id.saveBtn);
        final RadioButton kobieta = findViewById(R.id.kobieta);
        final RadioButton mezczyzna = findViewById(R.id.mezczyzna);

        sharedPreferences = getSharedPreferences("TrainThatApp", MODE_PRIVATE);
        Log.d("SHARED", sharedPreferences.toString());

        if(sharedPreferences.getString("name", null) != null &&
        sharedPreferences.getString("gender", null) != null && sharedPreferences.getLong("age", 0) != 0){

            imieView.setText(sharedPreferences.getString("name", null));
            wiekView.setText(String.valueOf(sharedPreferences.getLong("age", 0)));
            switch(sharedPreferences.getString("gender", null)){

                case "kobieta":
                    kobieta.setChecked(true);
                    pl = "kobieta";
                    break;
                case "mężczyzna":
                    mezczyzna.setChecked(true);
                    pl = "mężczyzna";
                    break;

            }
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item, aktywnosc);

        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int id, long position) {
                switch ((int) position){
                    case 0:
                        akt = 1;
                        break;
                    case 1:
                        akt = 2;
                        break;
                    case 2:
                        akt = 3;
                        break;
                    case 3:
                        akt = 4;
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                akt = 1;
            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(EditProfile.this);
                builder.setTitle(R.string.personal_data_title);
                builder.setMessage(R.string.personal_data_subtitle);
                builder.setPositiveButton("Zatwierdź", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if(!autoryzacja()){
                            return;
                        }

                        Map<String, Object> user = new HashMap<>();
                        user.put("name", imieView.getText().toString());
                        user.put("age", Long.parseLong(wiekView.getText().toString()));
                        user.put("gender", pl);
                        user.put("active", akt);
                        createUser(user);

                        dialog.dismiss();
                        finish();
                    }
                }).setNegativeButton("Anuluj", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).show();
            }
        });
    }

    public void radioClick(View view){
        boolean checked = ((RadioButton)view).isChecked();
        switch(view.getId()){
            case R.id.kobieta:
                if(checked){
                    pl = "kobieta";
                }
                break;
            case R.id.mezczyzna:
                if(checked){
                    pl = "mężczyzna";
                }
                break;
        }
    }

    private boolean autoryzacja(){

        boolean ok = true;
        int aktywnosc = this.akt;
        String plec = this.pl;

        EditText imieView = findViewById(R.id.imieEt);
        EditText wiekView = findViewById(R.id.wiekEt);

        if(aktywnosc == 0){
            Toast.makeText(EditProfile.this, "Błąd: nie wybrano aktywności.", Toast.LENGTH_SHORT).show();
            ok = false;
        }

        if(plec.equals("")){
            Toast.makeText(EditProfile.this, "Błąd: nie wybrano płci.", Toast.LENGTH_SHORT).show();
            ok = false;
        }

        if(!TextUtils.isEmpty(imieView.getText().toString())){
            imieView.setError(null);
        }
        else{
            imieView.setError("Pole nie może być puste.");
            ok = false;
        }

        if(!TextUtils.isEmpty(wiekView.getText().toString())){
            if(Integer.parseInt(wiekView.getText().toString()) < 110){
                wiekView.setError(null);
            }
            else{
                wiekView.setError("Ups! Na pewno masz " + wiekView.getText().toString() + " lat?");
                ok = false;
            }
        }
        else{
            wiekView.setError("Pole nie może być puste.");
            ok = false;
        }


        return ok;
    }

    public void createUser(Map<String, Object> map){
        try{
            FirebaseFirestore db = FirebaseFirestore.getInstance();

            db.collection("users").document(user.getUid()).set(map, SetOptions.merge())
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Log.d("Added", "DocumentSnapshot successfully written!");
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.w("ERROR", "Error writing document", e);
                }
            });

            sharedPreferences = getSharedPreferences("TrainThatApp", MODE_PRIVATE);
            SharedPreferences.Editor edit = sharedPreferences.edit();

            edit.putString("name", map.get("name").toString());
            edit.putLong("age", (Long) map.get("age"));
            edit.putString("gender", map.get("gender").toString());

            int active = (int) map.get("active");

            if (active == 0) {
            } else if (active == 1) {
                edit.putString("active", "Brak aktywności fizycznej");
            } else if (active == 2) {
                edit.putString("active", "Mała aktywność fizyczna");
            } else if (active == 3) {
                edit.putString("active", "średnia aktywność fizyczna");
            } else if (active == 4) {
                edit.putString("active", "Duża aktywność fizyczna");
            }

            edit.apply();
        }
        catch(Exception e){
            Log.e("ERROR", e.getMessage());
        }


    }
}
